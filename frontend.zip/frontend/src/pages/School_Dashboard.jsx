export const School_Dashboard=()=>{
    return (
        <div>
            asdlfjalkf 
        </div>
    )
} 